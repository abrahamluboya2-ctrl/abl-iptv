/* ==========================================
   IPTV Admin Panel JavaScript
   ========================================== */

// Default data (mirrors main app)
const defaultChannels = [
    { id: 1, name: "TF1", logo: "📺", quality: "fhd", category: "general", number: 1, now: "Journal TF1", next: "Le 20h00", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 2, name: "France 2", logo: "📺", quality: "fhd", category: "general", number: 2, now: "Journal", next: "Documentaire", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 3, name: "Canal+", logo: "📺", quality: "4k", category: "premium", number: 4, now: "Film", next: "Série", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 4, name: "BFM TV", logo: "📰", quality: "fhd", category: "news", number: 15, now: "Le 18h", next: "Info", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 5, name: "BeIN Sports 1", logo: "🏆", quality: "4k", category: "sports", number: 19, now: "Football", next: "Interview", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 6, name: "Disney Channel", logo: "🏰", quality: "hd", category: "youth", number: 27, now: "Dessin animé", next: "Série", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
];

const defaultMovies = [
    { id: 1, title: "Inception", poster: "🎬", year: 2010, duration: "2h 28min", genre: "action", rating: 8.8, description: "Un voleur qui s'infiltre dans les rêves..." },
    { id: 2, title: "The Dark Knight", poster: "🎬", year: 2008, duration: "2h 32min", genre: "action", rating: 9.0, description: "Batman affronte le Joker..." },
];

const defaultSeries = [
    { id: 1, title: "Breaking Bad", poster: "📺", year: 2008, seasons: 5, genre: "drama", rating: 9.5, description: "Un professeur devient trafiquant..." },
    { id: 2, title: "Game of Thrones", poster: "📺", year: 2011, seasons: 8, genre: "fantasy", rating: 9.3, description: "Bataille pour le Trône de Fer..." },
];

// State
let channels = [];
let movies = [];
let series = [];

// ==========================================
// Initialization
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

function initializeAdmin() {
    loadData();
    setupNavigation();
    renderAll();
}

function loadData() {
    // Load from localStorage or use defaults
    const storedChannels = localStorage.getItem('iptv_channels');
    const storedMovies = localStorage.getItem('iptv_movies');
    const storedSeries = localStorage.getItem('iptv_series');
    
    channels = storedChannels ? JSON.parse(storedChannels) : [...defaultChannels];
    movies = storedMovies ? JSON.parse(storedMovies) : [...defaultMovies];
    series = storedSeries ? JSON.parse(storedSeries) : [...defaultSeries];
}

function saveData() {
    localStorage.setItem('iptv_channels', JSON.stringify(channels));
    localStorage.setItem('iptv_movies', JSON.stringify(movies));
    localStorage.setItem('iptv_series', JSON.stringify(series));
}

function setupNavigation() {
    document.querySelectorAll('.sidebar-nav li').forEach(item => {
        item.addEventListener('click', function() {
            const page = this.dataset.page;
            switchPage(page);
        });
    });
}

function switchPage(pageName) {
    // Update sidebar
    document.querySelectorAll('.sidebar-nav li').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pageName) {
            item.classList.add('active');
        }
    });
    
    // Update pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(`${pageName}-page`).classList.add('active');
    
    // Update header
    const titles = {
        'channels': 'Gestion des chaînes',
        'movies': 'Gestion des films',
        'series': 'Gestion des séries',
        'add-bulk': 'Ajout multiple',
        'export': 'Exporter'
    };
    
    const subtitles = {
        'channels': 'Ajoutez et gérez vos chaînes IPTV',
        'movies': 'Ajoutez et gérez votre bibliothèque de films',
        'series': 'Ajoutez et gérez vos séries TV',
        'add-bulk': 'Ajoutez plusieurs chaînes en une fois',
        'export': 'Sauvegardez et exportez vos données'
    };
    
    document.getElementById('page-title').textContent = titles[pageName] || pageName;
    document.getElementById('page-subtitle').textContent = subtitles[pageName] || '';
}

function renderAll() {
    renderChannels();
    renderMovies();
    renderSeries();
    updateStats();
}

// ==========================================
// Render Functions
// ==========================================
function renderChannels(filteredChannels = channels) {
    const list = document.getElementById('channels-list');
    
    if (filteredChannels.length === 0) {
        list.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 40px;">Aucune chaîne ajoutée</p>';
        return;
    }
    
    // Sort by number
    filteredChannels.sort((a, b) => (a.number || 0) - (b.number || 0));
    
    list.innerHTML = filteredChannels.map(channel => `
        <div class="channel-item" data-id="${channel.id}">
            <div class="channel-logo">${channel.logo}</div>
            <div class="channel-info">
                <h4>${channel.name}</h4>
                <div class="channel-meta">
                    <span class="channel-quality">${channel.quality.toUpperCase()}</span>
                    <span>${getCategoryLabel(channel.category)}</span>
                    <span>№ ${channel.number || '-'}</span>
                </div>
                <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 6px;">
                    ${channel.now ? 'Maintenant: ' + channel.now : ''}
                </div>
            </div>
            <div class="channel-actions">
                <button onclick="editChannel(${channel.id})" title="Modifier"><i class="fas fa-edit"></i></button>
                <button onclick="deleteChannel(${channel.id})" class="delete-btn" title="Supprimer"><i class="fas fa-trash"></i></button>
            </div>
        </div>
    `).join('');
}

function renderMovies(filteredMovies = movies) {
    const list = document.getElementById('movies-list');
    
    if (filteredMovies.length === 0) {
        list.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 40px;">Aucun film ajouté</p>';
        return;
    }
    
    list.innerHTML = filteredMovies.map(movie => `
        <div class="content-item">
            <div class="content-poster">${movie.poster}</div>
            <div class="content-details">
                <h4>${movie.title}</h4>
                <div class="content-meta">
                    <span>${movie.year}</span>
                    <span>${movie.duration}</span>
                    <span>⭐ ${movie.rating}</span>
                </div>
                <div class="content-actions">
                    <button class="edit-btn" onclick="editMovie(${movie.id})">Modifier</button>
                    <button class="delete-btn" onclick="deleteMovie(${movie.id})">Supprimer</button>
                </div>
            </div>
        </div>
    `).join('');
}

function renderSeries(filteredSeries = series) {
    const list = document.getElementById('series-list');
    
    if (filteredSeries.length === 0) {
        list.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 40px;">Aucune série ajoutée</p>';
        return;
    }
    
    list.innerHTML = filteredSeries.map(show => `
        <div class="content-item">
            <div class="content-poster">${show.poster}</div>
            <div class="content-details">
                <h4>${show.title}</h4>
                <div class="content-meta">
                    <span>${show.year}</span>
                    <span>${show.seasons} saisons</span>
                    <span>⭐ ${show.rating}</span>
                </div>
                <div class="content-actions">
                    <button class="edit-btn" onclick="editSeries(${show.id})">Modifier</button>
                    <button class="delete-btn" onclick="deleteSeries(${show.id})">Supprimer</button>
                </div>
            </div>
        </div>
    `).join('');
}

function updateStats() {
    document.getElementById('total-channels').textContent = `${channels.length} chaînes`;
}

// ==========================================
// Filters
// ==========================================
function filterChannels() {
    const category = document.getElementById('category-filter').value;
    
    if (category === 'all') {
        renderChannels();
    } else {
        const filtered = channels.filter(c => c.category === category);
        renderChannels(filtered);
    }
}

// ==========================================
// Channel Management
// ==========================================
function addChannel(e) {
    e.preventDefault();
    
    const channel = {
        id: Date.now(),
        name: document.getElementById('channel-name').value,
        logo: document.getElementById('channel-logo').value || '📺',
        quality: document.getElementById('channel-quality').value,
        category: document.getElementById('channel-category').value,
        number: parseInt(document.getElementById('channel-number').value) || channels.length + 1,
        stream: document.getElementById('channel-stream').value,
        now: document.getElementById('channel-now').value || 'Programme',
        next: document.getElementById('channel-next').value || 'Programme'
    };
    
    channels.push(channel);
    saveData();
    renderChannels();
    updateStats();
    
    hideModal('add-channel-modal');
    document.getElementById('add-channel-form').reset();
    showToast('Chaîne ajoutée avec succès !', 'success');
}

function editChannel(channelId) {
    const channel = channels.find(c => c.id === channelId);
    if (!channel) return;
    
    // Populate form
    document.getElementById('channel-name').value = channel.name;
    document.getElementById('channel-logo').value = channel.logo;
    document.getElementById('channel-quality').value = channel.quality;
    document.getElementById('channel-category').value = channel.category;
    document.getElementById('channel-number').value = channel.number || '';
    document.getElementById('channel-stream').value = channel.stream;
    document.getElementById('channel-now').value = channel.now || '';
    document.getElementById('channel-next').value = channel.next || '';
    
    // Change form to edit mode
    const form = document.getElementById('add-channel-form');
    form.onsubmit = function(ev) {
        ev.preventDefault();
        
        channel.name = document.getElementById('channel-name').value;
        channel.logo = document.getElementById('channel-logo').value || '📺';
        channel.quality = document.getElementById('channel-quality').value;
        channel.category = document.getElementById('channel-category').value;
        channel.number = parseInt(document.getElementById('channel-number').value) || channels.length;
        channel.stream = document.getElementById('channel-stream').value;
        channel.now = document.getElementById('channel-now').value || 'Programme';
        channel.next = document.getElementById('channel-next').value || 'Programme';
        
        saveData();
        renderChannels();
        
        hideModal('add-channel-modal');
        form.reset();
        form.onsubmit = addChannel;
        showToast('Chaîne modifiée !', 'success');
    };
    
    showModal('add-channel-modal');
}

function deleteChannel(channelId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette chaîne ?')) return;
    
    channels = channels.filter(c => c.id !== channelId);
    saveData();
    renderChannels();
    updateStats();
    showToast('Chaîne supprimée !', 'success');
}

// ==========================================
// Movie Management
// ==========================================
function addMovie(e) {
    e.preventDefault();
    
    const movie = {
        id: Date.now(),
        title: document.getElementById('movie-title').value,
        poster: document.getElementById('movie-poster').value || '🎬',
        year: parseInt(document.getElementById('movie-year').value) || new Date().getFullYear(),
        duration: document.getElementById('movie-duration').value || '2h',
        genre: document.getElementById('movie-genre').value,
        rating: parseFloat(document.getElementById('movie-rating').value) || 0,
        url: document.getElementById('movie-url').value,
        description: document.getElementById('movie-description').value
    };
    
    movies.push(movie);
    saveData();
    renderMovies();
    
    hideModal('add-movie-modal');
    document.getElementById('add-movie-form').reset();
    showToast('Film ajouté avec succès !', 'success');
}

function editMovie(movieId) {
    const movie = movies.find(m => m.id === movieId);
    if (!movie) return;
    
    document.getElementById('movie-title').value = movie.title;
    document.getElementById('movie-poster').value = movie.poster;
    document.getElementById('movie-year').value = movie.year;
    document.getElementById('movie-duration').value = movie.duration;
    document.getElementById('movie-genre').value = movie.genre;
    document.getElementById('movie-rating').value = movie.rating;
    document.getElementById('movie-url').value = movie.url || '';
    document.getElementById('movie-description').value = movie.description || '';
    
    const form = document.getElementById('add-movie-form');
    form.onsubmit = function(ev) {
        ev.preventDefault();
        
        movie.title = document.getElementById('movie-title').value;
        movie.poster = document.getElementById('movie-poster').value || '🎬';
        movie.year = parseInt(document.getElementById('movie-year').value) || new Date().getFullYear();
        movie.duration = document.getElementById('movie-duration').value || '2h';
        movie.genre = document.getElementById('movie-genre').value;
        movie.rating = parseFloat(document.getElementById('movie-rating').value) || 0;
        movie.url = document.getElementById('movie-url').value;
        movie.description = document.getElementById('movie-description').value;
        
        saveData();
        renderMovies();
        
        hideModal('add-movie-modal');
        form.reset();
        form.onsubmit = addMovie;
        showToast('Film modifié !', 'success');
    };
    
    showModal('add-movie-modal');
}

function deleteMovie(movieId) {
    if (!confirm('Supprimer ce film ?')) return;
    
    movies = movies.filter(m => m.id !== movieId);
    saveData();
    renderMovies();
    showToast('Film supprimé !', 'success');
}

// ==========================================
// Series Management
// ==========================================
function addSeries(e) {
    e.preventDefault();
    
    const show = {
        id: Date.now(),
        title: document.getElementById('series-title').value,
        poster: document.getElementById('series-poster').value || '📺',
        year: parseInt(document.getElementById('series-year').value) || new Date().getFullYear(),
        seasons: parseInt(document.getElementById('series-seasons').value) || 1,
        genre: document.getElementById('series-genre').value,
        rating: parseFloat(document.getElementById('series-rating').value) || 0,
        description: document.getElementById('series-description').value
    };
    
    series.push(show);
    saveData();
    renderSeries();
    
    hideModal('add-series-modal');
    document.getElementById('add-series-form').reset();
    showToast('Série ajoutée avec succès !', 'success');
}

function editSeries(seriesId) {
    const show = series.find(s => s.id === seriesId);
    if (!show) return;
    
    document.getElementById('series-title').value = show.title;
    document.getElementById('series-poster').value = show.poster;
    document.getElementById('series-year').value = show.year;
    document.getElementById('series-seasons').value = show.seasons;
    document.getElementById('series-genre').value = show.genre;
    document.getElementById('series-rating').value = show.rating;
    document.getElementById('series-description').value = show.description || '';
    
    const form = document.getElementById('add-series-form');
    form.onsubmit = function(ev) {
        ev.preventDefault();
        
        show.title = document.getElementById('series-title').value;
        show.poster = document.getElementById('series-poster').value || '📺';
        show.year = parseInt(document.getElementById('series-year').value) || new Date().getFullYear();
        show.seasons = parseInt(document.getElementById('series-seasons').value) || 1;
        show.genre = document.getElementById('series-genre').value;
        show.rating = parseFloat(document.getElementById('series-rating').value) || 0;
        show.description = document.getElementById('series-description').value;
        
        saveData();
        renderSeries();
        
        hideModal('add-series-modal');
        form.reset();
        form.onsubmit = addSeries;
        showToast('Série modifiée !', 'success');
    };
    
    showModal('add-series-modal');
}

function deleteSeries(seriesId) {
    if (!confirm('Supprimer cette série ?')) return;
    
    series = series.filter(s => s.id !== seriesId);
    saveData();
    renderSeries();
    showToast('Série supprimée !', 'success');
}

// ==========================================
// Bulk Add
// ==========================================
function processBulkAdd() {
    const input = document.getElementById('bulk-input').value.trim();
    
    if (!input) {
        showToast('Veuillez entrer des chaînes', 'error');
        return;
    }
    
    const lines = input.split('\n').filter(line => line.trim());
    let added = 0;
    let errors = [];
    
    lines.forEach((line, index) => {
        const parts = line.split('|').map(p => p.trim());
        
        if (parts.length < 3) {
            errors.push(`Ligne ${index + 1}: Format invalide`);
            return;
        }
        
        const channel = {
            id: Date.now() + index,
            name: parts[0],
            logo: parts[1] || '📺',
            stream: parts[2],
            category: parts[3] || 'general',
            quality: parts[4] || 'hd',
            number: parseInt(parts[5]) || channels.length + added + 1,
            now: parts[6] || 'Programme',
            next: parts[7] || 'Programme'
        };
        
        channels.push(channel);
        added++;
    });
    
    saveData();
    renderChannels();
    updateStats();
    
    let message = `${added} chaîne(s) ajoutée(s) !`;
    if (errors.length > 0) {
        message += ` ${errors.length} erreur(s)`;
    }
    
    showToast(message, errors.length > 0 ? 'error' : 'success');
    
    document.getElementById('bulk-input').value = '';
}

// ==========================================
// Xtream Codes Connection
// ==========================================
function connectXtream(e) {
    e.preventDefault();
    
    const url = document.getElementById('xtream-url').value.trim();
    const username = document.getElementById('xtream-username').value.trim();
    const password = document.getElementById('xtream-password').value.trim();
    const type = document.getElementById('xtream-type').value;
    const statusEl = document.getElementById('xtream-status');
    
    statusEl.className = 'connection-status loading';
    statusEl.textContent = 'Connexion au serveur...';
    
    // Build API URLs
    const baseUrl = url.replace(/\/$/, '');
    
    // Simulate connection (in real app, would make actual API calls)
    setTimeout(() => {
        // Demo mode - show simulated success
        statusEl.className = 'connection-status success';
        statusEl.innerHTML = '<i class="fas fa-check-circle"></i> Connexion établie ! Import en cours...';
        
        // Simulate import result
        const importedChannels = Math.floor(Math.random() * 50) + 20;
        
        // Add demo channels
        for (let i = 0; i < importedChannels; i++) {
            channels.push({
                id: Date.now() + i,
                name: `Chaîne Xtream ${i + 1}`,
                logo: '📺',
                quality: 'hd',
                category: 'general',
                number: channels.length + 1,
                now: 'Programme',
                next: 'Programme',
                stream: 'https://exemple.com/stream.m3u8'
            });
        }
        
        saveData();
        renderChannels();
        updateStats();
        
        // Show import results
        document.getElementById('import-history').style.display = 'block';
        document.getElementById('import-channels').textContent = importedChannels;
        document.getElementById('import-movies').textContent = '0';
        document.getElementById('import-series').textContent = '0';
        
        showToast(`${importedChannels} chaînes importées avec succès !`, 'success');
        
        statusEl.innerHTML = `<i class="fas fa-check-circle"></i> Import terminé : ${importedChannels} chaînes`;
    }, 2000);
}

// ==========================================
// M3U Import
// ==========================================
function handleM3UFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('m3u-input').value = e.target.result;
        showToast('Fichier chargé avec succès !', 'success');
    };
    reader.readAsText(file);
}

function importM3U() {
    let m3uContent = document.getElementById('m3u-input').value.trim();
    
    if (!m3uContent) {
        showToast('Veuillez coller le contenu M3U ou téléverser un fichier', 'error');
        return;
    }
    
    const merge = document.getElementById('m3u-merge').checked;
    const useCategories = document.getElementById('m3u-categories').checked;
    
    if (!merge) {
        channels = [];
        movies = [];
        series = [];
    }
    
    const lines = m3uContent.split('\n');
    let currentLogo = '📺';
    let currentCategory = 'general';
    let currentQuality = 'hd';
    let channelCount = 0;
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        if (!line) continue;
        
        // Parse EXTINF line
        if (line.startsWith('#EXTINF:')) {
            // Extract logo from tvg-logo
            const logoMatch = line.match(/tvg-logo="([^"]*)"/);
            currentLogo = logoMatch ? logoMatch[1] : '📺';
            
            // Extract category from group-title
            const categoryMatch = line.match(/group-title="([^"]*)"/);
            if (categoryMatch && useCategories) {
                currentCategory = mapCategory(categoryMatch[1]);
            }
            
            // Extract quality from quality attribute
            const qualityMatch = line.match(/quality="([^"]*)"/);
            if (qualityMatch) {
                currentQuality = qualityMatch[1].toLowerCase();
            }
            
            // Extract channel number
            const numMatch = line.match(/tvg-chno="([^"]*)"/);
            
            // Extract name (after last comma)
            const name = line.split(',').pop().trim();
            
            // Get next line as stream URL
            if (i + 1 < lines.length) {
                const nextLine = lines[i + 1].trim();
                if (nextLine && !nextLine.startsWith('#')) {
                    channels.push({
                        id: Date.now() + channelCount,
                        name: name,
                        logo: currentLogo,
                        quality: currentQuality,
                        category: currentCategory,
                        number: numMatch ? parseInt(numMatch[1]) : channels.length + 1,
                        now: 'Programme',
                        next: 'Programme',
                        stream: nextLine
                    });
                    channelCount++;
                    i++; // Skip next line since we used it
                }
            }
        }
    }
    
    saveData();
    renderChannels();
    renderMovies();
    renderSeries();
    updateStats();
    
    // Show import results
    document.getElementById('import-history').style.display = 'block';
    document.getElementById('import-channels').textContent = channelCount;
    document.getElementById('import-movies').textContent = '0';
    document.getElementById('import-series').textContent = '0';
    
    showToast(`${channelCount} chaînes importées avec succès !`, 'success');
}

function mapCategory(categoryName) {
    const categoryMap = {
        'general': 'general',
        'entertainment': 'entertainment',
        'movies': 'movies',
        'series': 'series',
        'sports': 'sports',
        'news': 'news',
        'documentary': 'documentary',
        'music': 'music',
        'kids': 'youth',
        'youth': 'youth',
        'culture': 'culture',
        'nature': 'nature',
        'religion': 'religion',
        'movie': 'movies',
        'tv': 'general',
        'live': 'general'
    };
    
    const lower = categoryName.toLowerCase().trim();
    return categoryMap[lower] || 'general';
}

// ==========================================
// Export Functions
// ==========================================
function exportToJSON() {
    const data = {
        channels: channels,
        movies: movies,
        series: series,
        exportedAt: new Date().toISOString()
    };
    
    const json = JSON.stringify(data, null, 2);
    
    document.getElementById('export-output').style.display = 'block';
    document.getElementById('export-textarea').value = json;
    showToast('JSON généré !', 'success');
}

function exportToM3U() {
    let m3u = '#EXTM3U\n\n';
    
    channels.forEach(channel => {
        m3u += `#EXTINF:-1 tvg-logo="${channel.logo}" tvg-chno="${channel.number}" group-title="${channel.category}",${channel.name}\n`;
        m3u += `${channel.stream}\n\n`;
    });
    
    document.getElementById('export-output').style.display = 'block';
    document.getElementById('export-textarea').value = m3u;
    showToast('M3U généré !', 'success');
}

function exportForApp() {
    let code = '// ===== GÉNÉRÉ LE ' + new Date().toLocaleString() + ' =====\n\n';
    
    code += 'const channels = [\n';
    channels.forEach((c, i) => {
        code += `  { id: ${c.id}, name: "${c.name}", logo: "${c.logo}", quality: "${c.quality}", category: "${c.category}", number: ${c.number}, now: "${c.now}", next: "${c.next}", stream: "${c.stream}" }`;
        code += i < channels.length - 1 ? ',\n' : '\n';
    });
    code += '];\n\n';
    
    code += 'const movies = [\n';
    movies.forEach((m, i) => {
        code += `  { id: ${m.id}, title: "${m.title}", poster: "${m.poster}", year: ${m.year}, duration: "${m.duration}", genre: "${m.genre}", rating: ${m.rating}, description: "${m.description}" }`;
        code += i < movies.length - 1 ? ',\n' : '\n';
    });
    code += '];\n\n';
    
    code += 'const series = [\n';
    series.forEach((s, i) => {
        code += `  { id: ${s.id}, title: "${s.title}", poster: "${s.poster}", year: ${s.year}, seasons: ${s.seasons}, genre: "${s.genre}", rating: ${s.rating}, description: "${s.description}" }`;
        code += i < series.length - 1 ? ',\n' : '\n';
    });
    code += '];\n';
    
    document.getElementById('export-output').style.display = 'block';
    document.getElementById('export-textarea').value = code;
    showToast('Code généré !', 'success');
}

function copyExport() {
    const textarea = document.getElementById('export-textarea');
    textarea.select();
    document.execCommand('copy');
    showToast('Copié dans le presse-papiers !', 'success');
}

// ==========================================
// Utility Functions
// ==========================================
function showModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function hideModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
    
    // Reset form handlers
    const formIds = ['add-channel-form', 'add-movie-form', 'add-series-form'];
    formIds.forEach(id => {
        const form = document.getElementById(id);
        if (form) {
            form.reset();
            if (id === 'add-channel-form') form.onsubmit = addChannel;
            if (id === 'add-movie-form') form.onsubmit = addMovie;
            if (id === 'add-series-form') form.onsubmit = addSeries;
        }
    });
}

function getCategoryLabel(category) {
    const labels = {
        'general': 'Général',
        'news': 'Actualités',
        'sports': 'Sports',
        'entertainment': 'Divertissement',
        'movies': 'Cinéma',
        'documentary': 'Documentaires',
        'music': 'Musique',
        'youth': 'Jeunesse',
        'culture': 'Culture',
        'nature': 'Nature',
        'religion': 'Religion',
        'premium': 'Premium'
    };
    return labels[category] || category;
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.4s ease reverse';
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// Close modals on outside click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// Close modals on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.active').forEach(modal => {
            modal.classList.remove('active');
        });
    }
});