/* ==========================================
   IPTV Pro - Application JavaScript
   ========================================== */

// ==========================================
// Data - Channels, Movies, Series
// ==========================================
const channels = [
    { id: 1, name: "TF1", logo: "📺", quality: "fhd", category: "general", number: 1, now: "Journal TF1", next: "Le 20h00", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 2, name: "France 2", logo: "📺", quality: "fhd", category: "general", number: 2, now: "Journal", next: "Documentaire", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 3, name: "France 3", logo: "📺", quality: "hd", category: "general", number: 3, now: "Le 12/13", next: "Météo", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 4, name: "Canal+", logo: "📺", quality: "4k", category: "premium", number: 4, now: "Film", next: "Série", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 5, name: "France 5", logo: "📺", quality: "hd", category: "general", number: 5, now: "C dans l'air", next: "Le 23h", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 6, name: "M6", logo: "📺", quality: "fhd", category: "general", number: 6, now: "Le 12.45", next: "Scènes de ménages", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 7, name: "Arte", logo: "🎨", quality: "fhd", category: "culture", number: 7, now: "Documentaire", next: "Film", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 8, name: "C8", logo: "📺", quality: "hd", category: "entertainment", number: 8, now: "TPMP", next: "Le JT", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 9, name: "W9", logo: "📺", quality: "hd", category: "music", number: 9, now: "Clip", next: "Hit", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 10, name: "TMC", logo: "📺", quality: "hd", category: "general", number: 10, now: "Quotidien", next: "Le 19h", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 11, name: "TFX", logo: "📺", quality: "hd", category: "reality", number: 11, now: "Téléréalité", next: "Reportage", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 12, name: "NRJ 12", logo: "📺", quality: "hd", category: "entertainment", number: 12, now: "Spectacle", next: "Musique", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 13, name: "LCP", logo: "📺", quality: "hd", category: "news", number: 13, now: "Politique", next: "Débat", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 14, name: "France 4", logo: "📺", quality: "hd", category: "youth", number: 14, now: "Dessin animé", next: "Série", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 15, name: "BFM TV", logo: "📰", quality: "fhd", category: "news", number: 15, now: "Le 18h", next: "Info", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 16, name: "CNews", logo: "📰", quality: "hd", category: "news", number: 16, now: "Le 12h", next: "Info", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 17, name: "LCI", logo: "📰", quality: "hd", category: "news", number: 17, now: "Le 14h", next: "Débat", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 18, name: "Eurosport 1", logo: "⚽", quality: "fhd", category: "sports", number: 18, now: "Tennis", next: "Cyclisme", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 19, name: "BeIN Sports 1", logo: "🏆", quality: "4k", category: "sports", number: 19, now: "Football", next: "Interview", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 20, name: "BeIN Sports 2", logo: "🏆", quality: "4k", category: "sports", number: 20, now: "Foot US", next: "Basket", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 21, name: "Comedy Central", logo: "😂", quality: "hd", category: "entertainment", number: 21, now: "South Park", next: "Friends", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 22, name: "MTV", logo: "🎵", quality: "hd", category: "music", number: 22, now: "Hits", next: "Clip", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 23, name: "Chasse & Pêche", logo: "🎣", quality: "hd", category: "nature", number: 23, now: "Documentaire", next: "Magazine", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 24, name: "Planète+", logo: "🌍", quality: "fhd", category: "documentary", number: 24, now: "Nature", next: "Science", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 25, name: "Discovery", logo: "🔬", quality: "hd", category: "documentary", number: 25, now: "Science", next: "Technologie", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 26, name: "National Geographic", logo: "🗺️", quality: "fhd", category: "documentary", number: 26, now: "Voyage", next: "Histoire", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 27, name: "Disney Channel", logo: "🏰", quality: "hd", category: "youth", number: 27, now: "Dessin animé", next: "Série", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 28, name: "Nickelodeon", logo: "🎮", quality: "hd", category: "youth", number: 28, now: "Dora", next: "SpongeBob", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 29, name: "Cartoon Network", logo: "🎬", quality: "hd", category: "youth", number: 29, now: "Looney Tunes", next: "Adventure Time", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
    { id: 30, name: "AB1", logo: "🎬", quality: "hd", category: "movies", number: 30, now: "Film", next: "Cinéma", stream: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" },
];

const movies = [
    { id: 1, title: "Inception", poster: "🎬", year: 2010, duration: "2h 28min", genre: "action", rating: 8.8, quality: "4k", description: "Un voleur qui s'infiltre dans les rêves..." },
    { id: 2, title: "The Dark Knight", poster: "🎬", year: 2008, duration: "2h 32min", genre: "action", rating: 9.0, quality: "4k", description: "Batman affronte le Joker à Gotham..." },
    { id: 3, title: "Interstellar", poster: "🎬", year: 2014, duration: "2h 49min", genre: "sci-fi", rating: 8.6, quality: "4k", description: "Une équipe d'explorateurs voyage à travers un trou de ver..." },
    { id: 4, title: "Parasite", poster: "🎬", year: 2019, duration: "2h 12min", genre: "drama", rating: 8.5, quality: "fhd", description: "Une famille pauvre s'infiltre dans la vie d'une famille riche..." },
    { id: 5, title: "The Godfather", poster: "🎬", year: 1972, duration: "2h 55min", genre: "drama", rating: 9.2, quality: "hd", description: "L'histoire de la famille Corleone..." },
    { id: 6, title: "Pulp Fiction", poster: "🎬", year: 1994, duration: "2h 34min", genre: "action", rating: 8.9, quality: "hd", description: "Plusieurs histoires entrelacées à Los Angeles..." },
    { id: 7, title: "The Shawshank Redemption", poster: "🎬", year: 1994, duration: "2h 22min", genre: "drama", rating: 9.3, quality: "hd", description: "Un homme condamné à la prison trouve l'espoir..." },
    { id: 8, title: "Forrest Gump", poster: "🎬", year: 1994, duration: "2h 22min", genre: "drama", rating: 8.8, quality: "hd", description: "L'histoire extraordinaire d'un homme simple..." },
    { id: 9, title: "Fight Club", poster: "🎬", year: 1999, duration: "2h 19min", genre: "drama", rating: 8.8, quality: "hd", description: "Un homme fatigué de sa vie rencontre un savonnier..." },
    { id: 10, title: "The Matrix", poster: "🎬", year: 1999, duration: "2h 16min", genre: "sci-fi", rating: 8.7, quality: "4k", description: "Un hacker découvre la vérité sur sa réalité..." },
    { id: 11, title: "Avengers: Endgame", poster: "🎬", year: 2019, duration: "3h 02min", genre: "action", rating: 8.4, quality: "4k", description: "Les Avengers rassemblent leurs forces pour vaincre Thanos..." },
    { id: 12, title: "Spider-Man: No Way Home", poster: "🎬", year: 2021, duration: "2h 28min", genre: "action", rating: 8.3, quality: "4k", description: "Peter Parker demande de l'aide à Doctor Strange..." },
];

const series = [
    { id: 1, title: "Breaking Bad", poster: "📺", year: 2008, seasons: 5, genre: "drama", rating: 9.5, description: "Un professeur de chimie devient trafiquant de drogue..." },
    { id: 2, title: "Game of Thrones", poster: "📺", year: 2011, seasons: 8, genre: "fantasy", rating: 9.3, description: "Des familles nobles se battent pour le contrôle du Trône de Fer..." },
    { id: 3, title: "Stranger Things", poster: "📺", year: 2016, seasons: 4, genre: "sci-fi", rating: 8.7, description: "Un groupe d'amis affronte des forces surnaturelles..." },
    { id: 4, title: "The Mandalorian", poster: "📺", year: 2019, seasons: 3, genre: "sci-fi", rating: 8.8, quality: "4k", description: "Un chasseur de primes mandalorien dans la galaxie..." },
    { id: 5, title: "The Crown", poster: "📺", year: 2016, seasons: 6, genre: "drama", rating: 8.6, description: "L'histoire du règne de la Reine Elizabeth II..." },
    { id: 6, title: "Squid Game", poster: "📺", year: 2021, seasons: 1, genre: "thriller", rating: 8.0, quality: "4k", description: "Des personnes désespérées participent à des jeux mortels..." },
    { id: 7, title: "Friends", poster: "📺", year: 1994, seasons: 10, genre: "comedy", rating: 8.9, description: "Six amis partagent leur vie à New York..." },
    { id: 8, title: "The Office", poster: "📺", year: 2005, seasons: 9, genre: "comedy", rating: 8.9, description: "La vie quotidienne des employés de Dunder Mifflin..." },
    { id: 9, title: "Sherlock", poster: "📺", year: 2010, seasons: 4, genre: "thriller", rating: 9.1, description: "Les enquêtes du détective Sherlock Holmes..." },
    { id: 10, title: "Narcos", poster: "📺", year: 2015, seasons: 3, genre: "drama", rating: 8.8, description: "L'histoire du trafic de drogue en Amérique du Sud..." },
];

const categories = [
    { id: "all", name: "Toutes", icon: "📡" },
    { id: "general", name: "Général", icon: "📺" },
    { id: "news", name: "Actualités", icon: "📰" },
    { id: "sports", name: "Sports", icon: "⚽" },
    { id: "entertainment", name: "Divertissement", icon: "🎭" },
    { id: "movies", name: "Cinéma", icon: "🎬" },
    { id: "series", name: "Séries", icon: "📺" },
    { id: "documentary", name: "Documentaires", icon: "🎥" },
    { id: "music", name: "Musique", icon: "🎵" },
    { id: "youth", name: "Jeunesse", icon: "🧒" },
    { id: "culture", name: "Culture", icon: "🎨" },
];

// ==========================================
// State Management
// ==========================================
let currentView = 'live';
let currentChannel = null;
let favorites = JSON.parse(localStorage.getItem('iptv_favorites')) || [];
let epgDate = new Date();
let isPlaying = false;
let videoElement = null;

// ==========================================
// Initialization
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize video element
    videoElement = document.getElementById('video-player');
    
    // Load data from localStorage (admin panel) or use defaults
    loadDataFromStorage();
    
    // Setup event listeners
    setupEventListeners();
    
    // Render all content
    renderChannels();
    renderMovies();
    renderSeries();
    renderFavorites();
    renderCategories();
    renderEPG();
    updateClock();
    
    // Update clock every second
    setInterval(updateClock, 1000);
    
    // Hide loading screen
    setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
    }, 1500);
}

function loadDataFromStorage() {
    // Load channels from admin panel localStorage
    const storedChannels = localStorage.getItem('iptv_channels');
    const storedMovies = localStorage.getItem('iptv_movies');
    const storedSeries = localStorage.getItem('iptv_series');
    
    if (storedChannels) {
        channels.length = 0;
        JSON.parse(storedChannels).forEach(c => channels.push(c));
    }
    
    if (storedMovies) {
        movies.length = 0;
        JSON.parse(storedMovies).forEach(m => movies.push(m));
    }
    
    if (storedSeries) {
        series.length = 0;
        JSON.parse(storedSeries).forEach(s => series.push(s));
    }
}

function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.sidebar-nav li').forEach(item => {
        item.addEventListener('click', function() {
            const view = this.dataset.view;
            switchView(view);
        });
    });
    
    // Search
    document.getElementById('search-input').addEventListener('input', handleSearch);
    document.getElementById('search-input').addEventListener('focus', function() {
        document.getElementById('search-results').classList.add('active');
    });
    document.getElementById('search-input').addEventListener('blur', function() {
        setTimeout(() => {
            document.getElementById('search-results').classList.remove('active');
        }, 200);
    });
    
    // Filters
    document.getElementById('genre-filter').addEventListener('change', filterMovies);
    
    // Video player controls
    setupVideoControls();
    
    // Quality menu
    document.querySelectorAll('.quality-option').forEach(btn => {
        btn.addEventListener('click', function() {
            setQuality(this.dataset.quality);
        });
    });
}

// ==========================================
// Navigation
// ==========================================
function switchView(view) {
    currentView = view;
    
    // Update sidebar
    document.querySelectorAll('.sidebar-nav li').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.view === view) {
            item.classList.add('active');
        }
    });
    
    // Update content views
    document.querySelectorAll('.content-view').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`${view}-view`).classList.add('active');
    
    // Update header
    const titles = {
        'live': 'Chaînes en direct',
        'movies': 'Films',
        'series': 'Séries TV',
        'favorites': 'Mes Favoris',
        'epg': 'Guide des programmes'
    };
    document.querySelector('.view-header h2').textContent = titles[view] || view;
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
}

// ==========================================
// Render Functions
// ==========================================
function renderChannels(filteredChannels = channels) {
    const grid = document.getElementById('channels-grid');
    
    grid.innerHTML = filteredChannels.map(channel => `
        <div class="channel-card" onclick="playChannel(${channel.id})">
            <div class="channel-logo">${channel.logo}</div>
            <div class="channel-info">
                <h4>${channel.name}</h4>
                <div class="channel-meta">
                    <span class="channel-quality">${channel.quality.toUpperCase()}</span>
                    <span>${channel.number}</span>
                </div>
                <div class="channel-now">Maintenant: ${channel.now}</div>
            </div>
        </div>
    `).join('');
    
    renderChannelList();
}

function renderChannelList() {
    const list = document.getElementById('channel-list-items');
    list.innerHTML = channels.map(channel => `
        <div class="channel-list-item ${currentChannel?.id === channel.id ? 'active' : ''}" onclick="playChannel(${channel.id})">
            <span>${channel.logo}</span>
            <span>${channel.name}</span>
        </div>
    `).join('');
}

function renderMovies(filteredMovies = movies) {
    const grid = document.getElementById('movies-grid');
    
    grid.innerHTML = filteredMovies.map(movie => `
        <div class="movie-card" onclick="showMovieDetail(${movie.id})">
            <div class="movie-poster">${movie.poster}</div>
            <div class="movie-overlay">
                <button class="play-overlay-btn"><i class="fas fa-play"></i></button>
            </div>
            <div class="movie-info">
                <h4>${movie.title}</h4>
                <div class="movie-meta">
                    <span class="movie-rating">⭐ ${movie.rating}</span>
                    <span>${movie.year}</span>
                    <span>${movie.duration}</span>
                </div>
                <div class="movie-genre">${getGenreLabel(movie.genre)}</div>
            </div>
        </div>
    `).join('');
}

function renderSeries(filteredSeries = series) {
    const grid = document.getElementById('series-grid');
    
    grid.innerHTML = filteredSeries.map(show => `
        <div class="series-card" onclick="showSeriesDetail(${show.id})">
            <div class="series-poster">${show.poster}</div>
            <div class="series-overlay">
                <button class="play-overlay-btn"><i class="fas fa-play"></i></button>
            </div>
            <div class="series-info">
                <h4>${show.title}</h4>
                <div class="series-meta">
                    <span class="movie-rating">⭐ ${show.rating}</span>
                    <span>${show.seasons} saisons</span>
                </div>
                <div class="movie-genre">${getGenreLabel(show.genre)}</div>
            </div>
        </div>
    `).join('');
}

function renderFavorites() {
    const grid = document.getElementById('favorites-grid');
    
    if (favorites.length === 0) {
        grid.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 40px;">Aucun favori ajouté</p>';
        return;
    }
    
    // Filter favorites by type
    const favChannels = favorites.filter(f => f.type === 'channel');
    const favMovies = favorites.filter(f => f.type === 'movie');
    const favSeries = favorites.filter(f => f.type === 'series');
    
    let html = '';
    
    favChannels.forEach(fav => {
        const channel = channels.find(c => c.id === fav.id);
        if (channel) {
            html += `
                <div class="favorite-card" onclick="playChannel(${channel.id})">
                    <div class="favorite-poster">${channel.logo}</div>
                    <div class="favorite-overlay">
                        <button class="play-overlay-btn"><i class="fas fa-play"></i></button>
                    </div>
                    <div class="favorite-info">
                        <h4>${channel.name}</h4>
                        <div class="favorite-meta">
                            <span>${channel.quality.toUpperCase()}</span>
                        </div>
                    </div>
                </div>
            `;
        }
    });
    
    favMovies.forEach(fav => {
        const movie = movies.find(m => m.id === fav.id);
        if (movie) {
            html += `
                <div class="favorite-card" onclick="showMovieDetail(${movie.id})">
                    <div class="favorite-poster">${movie.poster}</div>
                    <div class="favorite-overlay">
                        <button class="play-overlay-btn"><i class="fas fa-play"></i></button>
                    </div>
                    <div class="favorite-info">
                        <h4>${movie.title}</h4>
                        <div class="favorite-meta">
                            <span>⭐ ${movie.rating}</span>
                        </div>
                    </div>
                </div>
            `;
        }
    });
    
    favSeries.forEach(fav => {
        const show = series.find(s => s.id === fav.id);
        if (show) {
            html += `
                <div class="favorite-card" onclick="showSeriesDetail(${show.id})">
                    <div class="favorite-poster">${show.poster}</div>
                    <div class="favorite-overlay">
                        <button class="play-overlay-btn"><i class="fas fa-play"></i></button>
                    </div>
                    <div class="favorite-info">
                        <h4>${show.title}</h4>
                        <div class="favorite-meta">
                            <span>⭐ ${show.rating}</span>
                            <span>${show.seasons} saisons</span>
                        </div>
                    </div>
                </div>
            `;
        }
    });
    
    grid.innerHTML = html;
}

function renderCategories() {
    const list = document.getElementById('category-list');
    
    list.innerHTML = categories.map(cat => `
        <li class="${cat.id === 'all' ? 'active' : ''}" onclick="filterByCategory('${cat.id}')">
            <span>${cat.icon}</span>
            <span>${cat.name}</span>
            <span class="category-count">${cat.id === 'all' ? channels.length : channels.filter(c => c.category === cat.id).length}</span>
        </li>
    `).join('');
}

function renderEPG() {
    const container = document.getElementById('epg-container');
    const dateSpan = document.getElementById('epg-date');
    
    // Update date display
    if (epgDate.toDateString() === new Date().toDateString()) {
        dateSpan.textContent = "Aujourd'hui";
    } else {
        dateSpan.textContent = epgDate.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    }
    
    container.innerHTML = channels.slice(0, 10).map(channel => `
        <div class="epg-channel">
            <div class="epg-channel-logo">
                <span>${channel.logo}</span>
                <h4>${channel.name}</h4>
            </div>
            <div class="epg-programs">
                ${generateEPGPrograms(channel).map((program, idx) => `
                    <div class="epg-program ${idx === 2 ? 'now' : ''}">
                        <h5>${program.time}</h5>
                        <p>${program.title}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
}

function generateEPGPrograms(channel) {
    const now = new Date();
    const programs = [];
    
    for (let i = 0; i < 6; i++) {
        const time = new Date(now.getTime() + (i * 90 * 60000));
        const hour = time.getHours().toString().padStart(2, '0');
        const min = time.getMinutes().toString().padStart(2, '0');
        
        programs.push({
            time: `${hour}:${min}`,
            title: i === 0 ? channel.now : (i === 1 ? channel.next : `${channel.name} - Programme ${i + 1}`)
        });
    }
    
    return programs;
}

// ==========================================
// Filters
// ==========================================
function filterByCategory(categoryId) {
    // Update active category
    document.querySelectorAll('.category-list li').forEach(item => {
        item.classList.remove('active');
        if (item.onclick.toString().includes(categoryId)) {
            item.classList.add('active');
        }
    });
    
    if (categoryId === 'all') {
        renderChannels();
    } else {
        const filtered = channels.filter(c => c.category === categoryId);
        renderChannels(filtered);
    }
}

function filterMovies() {
    const genre = document.getElementById('genre-filter').value;
    
    if (genre === 'all') {
        renderMovies();
    } else {
        const filtered = movies.filter(m => m.genre === genre);
        renderMovies(filtered);
    }
}

function handleSearch(e) {
    const query = e.target.value.toLowerCase().trim();
    const results = document.getElementById('search-results');
    
    if (query.length < 2) {
        results.classList.remove('active');
        return;
    }
    
    // Search in channels, movies, and series
    const channelResults = channels.filter(c => c.name.toLowerCase().includes(query)).slice(0, 3);
    const movieResults = movies.filter(m => m.title.toLowerCase().includes(query)).slice(0, 3);
    const seriesResults = series.filter(s => s.title.toLowerCase().includes(query)).slice(0, 3);
    
    let html = '';
    
    if (channelResults.length > 0) {
        html += '<div class="search-section"><h4>Chaînes</h4>';
        channelResults.forEach(c => {
            html += `
                <div class="search-result-item" onclick="playChannel(${c.id})">
                    <div class="result-icon">${c.logo}</div>
                    <div class="search-result-info">
                        <h4>${c.name}</h4>
                        <p>${c.now}</p>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    if (movieResults.length > 0) {
        html += '<div class="search-section"><h4>Films</h4>';
        movieResults.forEach(m => {
            html += `
                <div class="search-result-item" onclick="showMovieDetail(${m.id})">
                    <div class="result-icon">${m.poster}</div>
                    <div class="search-result-info">
                        <h4>${m.title}</h4>
                        <p>${m.year} • ${m.duration}</p>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    if (seriesResults.length > 0) {
        html += '<div class="search-section"><h4>Séries</h4>';
        seriesResults.forEach(s => {
            html += `
                <div class="search-result-item" onclick="showSeriesDetail(${s.id})">
                    <div class="result-icon">${s.poster}</div>
                    <div class="search-result-info">
                        <h4>${s.title}</h4>
                        <p>${s.seasons} saisons • ${s.year}</p>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    if (!html) {
        html = '<div class="search-result-item"><p style="padding: 16px; color: var(--text-muted);">Aucun résultat trouvé</p></div>';
    }
    
    results.innerHTML = html;
    results.classList.add('active');
}

// ==========================================
// Video Player
// ==========================================
function playChannel(channelId) {
    const channel = channels.find(c => c.id === channelId);
    if (!channel) return;
    
    currentChannel = channel;
    
    // Update player info
    document.getElementById('player-title').textContent = channel.name;
    document.getElementById('player-quality').textContent = channel.quality.toUpperCase();
    
    // Show live badge for live TV
    document.getElementById('live-badge').classList.remove('hidden');
    
    // Update favorite icon
    updateFavoriteIcon();
    
    // Open player
    openPlayer();
    
    // In a real app, this would be the actual stream URL
    // For demo purposes, we'll use a test stream
    if (videoElement) {
        videoElement.src = channel.stream;
        videoElement.poster = '';
        videoElement.play().catch(e => console.log('Autoplay prevented'));
        isPlaying = true;
        updatePlayIcon();
    }
    
    renderChannelList();
    showToast(`Lecture de ${channel.name}`, 'success');
}

function playContent() {
    closeDetailModal();
    openPlayer();
    
    // For demo, play a test video
    if (videoElement) {
        videoElement.src = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
        videoElement.play().catch(e => console.log('Autoplay prevented'));
        isPlaying = true;
        updatePlayIcon();
    }
    
    document.getElementById('live-badge').classList.add('hidden');
}

function openPlayer() {
    document.getElementById('player-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closePlayer() {
    document.getElementById('player-modal').classList.remove('active');
    document.body.style.overflow = '';
    
    if (videoElement) {
        videoElement.pause();
        videoElement.src = '';
        isPlaying = false;
    }
    
    document.getElementById('channel-list-sidebar').classList.remove('active');
}

function setupVideoControls() {
    const video = videoElement;
    const progress = document.getElementById('video-progress');
    const progressInput = document.getElementById('progress-input');
    const volumeSlider = document.getElementById('volume-slider');
    
    video.addEventListener('timeupdate', function() {
        const percent = (video.currentTime / video.duration) * 100;
        progress.style.width = `${percent}%`;
        progressInput.value = percent;
        updateTimeDisplay();
    });
    
    video.addEventListener('loadedmetadata', function() {
        updateTimeDisplay();
    });
    
    progressInput.addEventListener('input', function() {
        const time = (this.value / 100) * video.duration;
        video.currentTime = time;
    });
    
    volumeSlider.addEventListener('input', function() {
        video.volume = this.value / 100;
        updateVolumeIcon();
    });
    
    // Click on progress bar
    document.querySelector('.progress-bar').addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        video.currentTime = percent * video.duration;
    });
}

function togglePlay() {
    if (!videoElement) return;
    
    if (isPlaying) {
        videoElement.pause();
    } else {
        videoElement.play();
    }
    
    isPlaying = !isPlaying;
    updatePlayIcon();
    document.getElementById('video-overlay').classList.toggle('hidden', isPlaying);
}

function updatePlayIcon() {
    const icon = document.getElementById('play-icon');
    icon.className = isPlaying ? 'fas fa-pause' : 'fas fa-play';
}

function updateTimeDisplay() {
    if (!videoElement) return;
    
    const current = formatTime(videoElement.currentTime);
    const duration = formatTime(videoElement.duration || 0);
    document.getElementById('time-display').textContent = `${current} / ${duration}`;
}

function formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function skipBackward() {
    if (videoElement) {
        videoElement.currentTime -= 10;
    }
}

function skipForward() {
    if (videoElement) {
        videoElement.currentTime += 10;
    }
}

function toggleMute() {
    if (!videoElement) return;
    
    videoElement.muted = !videoElement.muted;
    updateVolumeIcon();
}

function updateVolumeIcon() {
    const icon = document.getElementById('volume-icon');
    if (!videoElement) return;
    
    if (videoElement.muted || videoElement.volume === 0) {
        icon.className = 'fas fa-volume-mute';
    } else if (videoElement.volume < 0.5) {
        icon.className = 'fas fa-volume-down';
    } else {
        icon.className = 'fas fa-volume-up';
    }
}

function toggleQualityMenu() {
    document.getElementById('quality-menu').classList.toggle('active');
}

function setQuality(quality) {
    document.querySelectorAll('.quality-option').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.quality === quality) {
            btn.classList.add('active');
        }
    });
    document.getElementById('quality-menu').classList.remove('active');
    showToast(`Qualité: ${quality}`, 'info');
}

function toggleFullscreen() {
    const player = document.querySelector('.player-container');
    if (document.fullscreenElement) {
        document.exitFullscreen();
    } else {
        player.requestFullscreen();
    }
}

function openChannelList() {
    document.getElementById('channel-list-sidebar').classList.toggle('active');
}

function toggleFavoritesCurrent() {
    if (!currentChannel) return;
    
    const index = favorites.findIndex(f => f.type === 'channel' && f.id === currentChannel.id);
    
    if (index > -1) {
        favorites.splice(index, 1);
        showToast('Retiré des favoris', 'info');
    } else {
        favorites.push({ type: 'channel', id: currentChannel.id });
        showToast('Ajouté aux favoris', 'success');
    }
    
    localStorage.setItem('iptv_favorites', JSON.stringify(favorites));
    updateFavoriteIcon();
    renderFavorites();
}

function updateFavoriteIcon() {
    const icon = document.getElementById('favorite-icon');
    if (!currentChannel) return;
    
    const isFavorite = favorites.some(f => f.type === 'channel' && f.id === currentChannel.id);
    icon.className = isFavorite ? 'fas fa-heart' : 'far fa-heart';
}

function toggleFavorites() {
    switchView('favorites');
}

// ==========================================
// Detail Modals
// ==========================================
function showMovieDetail(movieId) {
    const movie = movies.find(m => m.id === movieId);
    if (!movie) return;
    
    document.getElementById('detail-title').textContent = movie.title;
    document.getElementById('detail-backdrop').innerHTML = movie.poster;
    document.getElementById('detail-quality').textContent = movie.quality.toUpperCase();
    document.getElementById('detail-rating').innerHTML = `<span class="movie-rating">⭐ ${movie.rating}</span>`;
    document.getElementById('detail-description').textContent = movie.description;
    
    // Update favorite button
    const isFavorite = favorites.some(f => f.type === 'movie' && f.id === movieId);
    document.querySelector('.btn-favorite').className = isFavorite ? 'btn-favorite active' : 'btn-favorite';
    
    document.getElementById('detail-modal').classList.add('active');
}

function showSeriesDetail(seriesId) {
    const show = series.find(s => s.id === seriesId);
    if (!show) return;
    
    document.getElementById('detail-title').textContent = show.title;
    document.getElementById('detail-backdrop').innerHTML = show.poster;
    document.getElementById('detail-quality').textContent = 'HD';
    document.getElementById('detail-rating').innerHTML = `<span class="movie-rating">⭐ ${show.rating}</span>`;
    document.getElementById('detail-description').textContent = show.description;
    
    // Add seasons info
    document.getElementById('detail-meta').innerHTML = `
        <span class="detail-year">${show.year}</span>
        <span class="detail-duration">${show.seasons} saisons</span>
        <span class="detail-quality">HD</span>
        <span class="detail-rating">⭐ ${show.rating}</span>
    `;
    
    // Update favorite button
    const isFavorite = favorites.some(f => f.type === 'series' && f.id === seriesId);
    document.querySelector('.btn-favorite').className = isFavorite ? 'btn-favorite active' : 'btn-favorite';
    
    document.getElementById('detail-modal').classList.add('active');
}

function closeDetailModal() {
    document.getElementById('detail-modal').classList.remove('active');
}

function toggleFavoriteDetail() {
    const btn = document.querySelector('.btn-favorite');
    const isMovie = document.getElementById('detail-title').textContent.includes(' ') && movies.find(m => m.title === document.getElementById('detail-title').textContent);
    
    if (isMovie) {
        const movie = movies.find(m => m.title === document.getElementById('detail-title').textContent);
        if (movie) {
            const index = favorites.findIndex(f => f.type === 'movie' && f.id === movie.id);
            if (index > -1) {
                favorites.splice(index, 1);
                btn.classList.remove('active');
                showToast('Retiré des favoris', 'info');
            } else {
                favorites.push({ type: 'movie', id: movie.id });
                btn.classList.add('active');
                showToast('Ajouté aux favoris', 'success');
            }
        }
    } else {
        const show = series.find(s => s.title === document.getElementById('detail-title').textContent);
        if (show) {
            const index = favorites.findIndex(f => f.type === 'series' && f.id === show.id);
            if (index > -1) {
                favorites.splice(index, 1);
                btn.classList.remove('active');
                showToast('Retiré des favoris', 'info');
            } else {
                favorites.push({ type: 'series', id: show.id });
                btn.classList.add('active');
                showToast('Ajouté aux favoris', 'success');
            }
        }
    }
    
    localStorage.setItem('iptv_favorites', JSON.stringify(favorites));
    renderFavorites();
}

// ==========================================
// Settings
// ==========================================
function openSettings() {
    document.getElementById('settings-modal').classList.add('active');
}

function closeSettings() {
    document.getElementById('settings-modal').classList.remove('active');
}

// ==========================================
// EPG Functions
// ==========================================
function changeEPGDate(days) {
    epgDate.setDate(epgDate.getDate() + days);
    renderEPG();
}

// ==========================================
// Utility Functions
// ==========================================
function updateClock() {
    const now = new Date();
    document.getElementById('current-time').textContent = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    document.getElementById('current-date').textContent = now.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
}

function getGenreLabel(genre) {
    const labels = {
        'action': 'Action',
        'comedy': 'Comédie',
        'drama': 'Drame',
        'horror': 'Horreur',
        'sci-fi': 'Science-Fiction',
        'romance': 'Romance',
        'fantasy': 'Fantasy',
        'thriller': 'Thriller',
        'documentary': 'Documentaire'
    };
    return labels[genre] || genre;
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    
    const icons = {
        'success': '✓',
        'error': '✕',
        'info': 'ℹ'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type]}</span>
        <span class="toast-message">${message}</span>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.4s ease reverse';
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// Close modals on outside click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('settings-modal')) {
        closeSettings();
    }
    if (e.target.classList.contains('detail-modal')) {
        closeDetailModal();
    }
});

// Close modals on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePlayer();
        closeSettings();
        closeDetailModal();
    }
});